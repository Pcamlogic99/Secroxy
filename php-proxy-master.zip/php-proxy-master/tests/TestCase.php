<?php

namespace Proxy\Tests;

abstract class TestCase extends \PHPUnit\Framework\TestCase
{
    // TODO
}